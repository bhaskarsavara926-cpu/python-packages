__version__ = '2.8.0+cpu'
git_version = '6e1c7fe9ff6d82b8665d0a46d859d3357d2ebaaa'
